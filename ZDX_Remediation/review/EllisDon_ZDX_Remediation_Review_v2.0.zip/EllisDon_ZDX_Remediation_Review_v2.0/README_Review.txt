EllisDon ZDX Remediation Library - Code Review Package
Author: Sinan Aldulaimi

Files for review
- Teams_Cache_Reset_v2.0.ps1
- Disk_Space_Cleanup_v2.0.ps1
- SHA256SUMS.txt (fingerprints of the two scripts; used to confirm the signed
  versions are exactly the reviewed versions)

How they run
- Uploaded to ZDX as signed scripts, run on one device at a time by the service desk.
- Run as SYSTEM (Elevated Permissions), same as the approved v1.4 diagnostic scripts.
- Output is returned to ZDX (Set-ZOutput / Set-ZResult) and also saved locally to
  C:\ProgramData\ZDX_Remediation\Logs (folder locked to SYSTEM/Administrators).
- Each script has a Settings block at the top. $DryRun = $true reports only and
  changes nothing.

Teams_Cache_Reset_v2.0.ps1 - what it changes
- Closes Teams for the logged-on user only (skipped if the user is in a call).
- Renames the Teams cache folder to MSTeams.bak_<date> (backup kept, not deleted);
  older backups beyond 1 are removed.
- Reopens Teams for the user if it was running.
- Re-enables the Outlook Teams Meeting add-in only if Outlook/user disabled it
  (LoadBehavior 2). Leaves it alone if disabled by company policy or a custom value.

Disk_Space_Cleanup_v2.0.ps1 - what it changes
- Runs only if C: has 20 GB free or less.
- Deletes: temp files older than 24h, error reports, crash dumps, browser cache
  (not cookies/passwords/history), Recycle Bin, Windows Update and Delivery
  Optimization caches; runs Windows Disk Cleanup; removes Windows.old and upgrade
  leftovers only if older than 10 days.
- Never touches Documents, Desktop, Downloads or the Outlook attachment temp folder.
- Large files and old profiles are reported only, never deleted.

Suggested review focus
1. Every delete path (Remove-OldItems, Remove-OneFile, Remove-UpgradeFolder).
2. Junction/symlink protection in user-writable folders (Test-IsLink, Test-LinkInPath).
3. Windows.old removal (allow-list of 4 fixed paths, robocopy /B /XJ, no ACL changes).
4. Registry changes (Teams add-in, cleanmgr StateFlags0777 - removed after run).
5. Services stopped/started (Teams processes; wuauserv/bits briefly for update cache).

Not done by either script
- No security settings, Defender, firewall, execution policy or Zscaler changes.
- No restarts, no network calls to external sites, no credentials used.
